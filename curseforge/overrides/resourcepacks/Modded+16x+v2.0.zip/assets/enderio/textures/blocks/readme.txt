

conduit.png:
  row 1: item conduit
  row 2: redstone conduit (outer)
  row 3: redstone conduit (inner), active
  row 4: redstone conduit (inner), inactive

liquid_conduit.png:
  row 1: liquid conduit
  row 2: advanced liquid conduit
  row 3: advanced liquid conduit, locked to one fluid type
  row 4: ender fluid conduit

power_conduit.png:
  row 1: tier 1 energy conduit
  row 2: tier 2 energy conduit
  row 3: tier 3 energy conduit
  row 4: unused

